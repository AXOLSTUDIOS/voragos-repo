/*
Voxy LoD patch for Legendary Atmosphere (BSL v10 based).
Voxy appends this code to its own LoD fragment shader (GLSL 460 core).
Lighting mirrors the pack's dh_terrain / dh_water forward lighting, trimmed
for far terrain: no shadow map lookups, no noise textures, no SSR.

Uniforms come from the Voxy uniform block (see voxy.json "uniforms") and are
all custom uniforms declared in shaders.properties.
Patch by Axolstudio.
*/

#include "/lib/settings.glsl"

//Uniform aliases (Voxy can only forward custom uniforms)//
#define rainStrength vx_rainStrength
#define nightVision  vx_nightVision
#define moonPhase    vx_moonPhase
#define eBS          vx_eBS

layout(location = 0) out vec4 vxFragOut0;

const vec3 vxUpVec   = vec3(0.0, 1.0, 0.0);
const vec3 vxEastVec = vec3(1.0, 0.0, 0.0);

float VxLuminance(vec3 color) {
	return dot(color, vec3(0.299, 0.587, 0.114));
}

vec3 VxFaceNormal(uint face) {
	float s = (face & 1u) == 1u ? 1.0 : -1.0;
	uint axis = face >> 1;
	if (axis == 0u) return vec3(0.0, s, 0.0);
	if (axis == 1u) return vec3(0.0, 0.0, s);
	return vec3(s, 0.0, 0.0);
}

//World-space sun direction, same math as the pack's vertex shaders minus gbufferModelView
vec3 VxSunVec() {
	const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
	float ang = fract(timeAngle - 0.25);
	ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
	return normalize(vec3(-sin(ang), cos(ang) * sunRotationData));
}

vec3 VxRGB2HSV(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

float VxHardcodedEmission(vec3 albedo, vec3 hsv) {
	#if EMISSIVE_HARDCODED == 0
	float saturatedEmission = clamp(hsv.y * 3.125 - 0.125, 0.0, 1.0) * pow(hsv.z, 4.0);
	float desaturatedEmission = clamp(hsv.z * 7.0 - 6.0, 0.0, 1.0);
	return max(saturatedEmission, desaturatedEmission) * 0.5;
	#else
	return pow(max(max(albedo.r, albedo.g), albedo.b), 4.0) * 0.4;
	#endif
}

//Shared lighting state, filled once per fragment//
struct VxLight {
	vec3 sunVec;
	vec3 lightVec;
	float sunVisibility;
	float sunSkyVisibility;
	vec3 lightSun;
	vec3 lightNight;
	vec3 lightCol;
	vec3 ambientCol;
	vec4 weatherCol;
	vec3 minLightCol;
	vec3 blocklightCol;
};

VxLight VxSetupLight() {
	VxLight L;
	L.sunVec = VxSunVec();
	L.lightVec = L.sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
	L.sunVisibility = clamp(dot(L.sunVec, vxUpVec) * 10.0 + 0.5, 0.0, 1.0);
	L.sunSkyVisibility = clamp(dot(L.sunVec, vxUpVec) * 2.0 + 0.5, 0.0, 1.0);

	vec3 blSqrt = vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B) * BLOCKLIGHT_I / 255.0;
	L.blocklightCol = blSqrt * blSqrt;

	vec3 minSqrt = vec3(MINLIGHT_R, MINLIGHT_G, MINLIGHT_B) * MINLIGHT_I / 255.0;
	L.minLightCol = minSqrt * minSqrt * 0.04;

	L.lightSun = vec3(0.0); L.lightNight = vec3(0.0);
	L.lightCol = vec3(0.0); L.ambientCol = vec3(0.0);
	L.weatherCol = vec4(1.0);

	#ifdef OVERWORLD
	vec3 lightMorning   = vec3(LIGHT_MR,   LIGHT_MG,   LIGHT_MB)   * LIGHT_MI / 255.0;
	vec3 lightDay       = vec3(LIGHT_DR,   LIGHT_DG,   LIGHT_DB)   * LIGHT_DI / 255.0;
	vec3 lightEvening   = vec3(LIGHT_ER,   LIGHT_EG,   LIGHT_EB)   * LIGHT_EI / 255.0;
	vec3 ambientMorning = vec3(AMBIENT_MR, AMBIENT_MG, AMBIENT_MB) * AMBIENT_MI / 255.0;
	vec3 ambientDay     = vec3(AMBIENT_DR, AMBIENT_DG, AMBIENT_DB) * AMBIENT_DI / 255.0;
	vec3 ambientEvening = vec3(AMBIENT_ER, AMBIENT_EG, AMBIENT_EB) * AMBIENT_EI / 255.0;

	#ifdef NIGHT_MOON_PHASE
	const float moonPhaseMultiplier[8] = float[8](1.0, 0.875, 0.75, 0.625, 0.5, 0.625, 0.75, 0.875);
	float nightMult = 0.3 * moonPhaseMultiplier[clamp(moonPhase, 0, 7)];
	#else
	float nightMult = 0.3;
	#endif
	L.lightNight         = vec3(LIGHT_NR,   LIGHT_NG,   LIGHT_NB)   * LIGHT_NI   * nightMult / 255.0;
	vec3 ambientNight    = vec3(AMBIENT_NR, AMBIENT_NG, AMBIENT_NB) * AMBIENT_NI * nightMult / 255.0;

	#ifdef WEATHER_PERBIOME
	vec4 weatherRain     = vec4(vec3(WEATHER_RR, WEATHER_RG, WEATHER_RB) / 255.0, 1.0) * WEATHER_RI;
	vec4 weatherColdC    = vec4(vec3(WEATHER_CR, WEATHER_CG, WEATHER_CB) / 255.0, 1.0) * WEATHER_CI;
	vec4 weatherDesertC  = vec4(vec3(WEATHER_DR, WEATHER_DG, WEATHER_DB) / 255.0, 1.0) * WEATHER_DI;
	vec4 weatherBadlands = vec4(vec3(WEATHER_BR, WEATHER_BG, WEATHER_BB) / 255.0, 1.0) * WEATHER_BI;
	vec4 weatherSwampC   = vec4(vec3(WEATHER_SR, WEATHER_SG, WEATHER_SB) / 255.0, 1.0) * WEATHER_SI;
	vec4 weatherMushroom = vec4(vec3(WEATHER_MR, WEATHER_MG, WEATHER_MB) / 255.0, 1.0) * WEATHER_MI;
	vec4 weatherSavannaC = vec4(vec3(WEATHER_VR, WEATHER_VG, WEATHER_VB) / 255.0, 1.0) * WEATHER_VI;
	vec4 weatherJungleC  = vec4(vec3(WEATHER_JR, WEATHER_JG, WEATHER_JB) / 255.0, 1.0) * WEATHER_JI;
	float weatherWeight = clamp(isCold + isDesert + isMesa + isSwamp + isMushroom + isSavanna + isJungle, 0.0, 1.0);
	L.weatherCol = mix(
		weatherRain,
		(weatherColdC  * isCold  + weatherDesertC  * isDesert   + weatherBadlands * isMesa    +
		 weatherSwampC * isSwamp + weatherMushroom * isMushroom + weatherSavannaC * isSavanna +
		 weatherJungleC * isJungle) / max(weatherWeight, 0.0001),
		weatherWeight
	);
	#else
	L.weatherCol = vec4(vec3(WEATHER_RR, WEATHER_RG, WEATHER_RB) / 255.0, 1.0) * WEATHER_RI;
	#endif

	float mefade = 1.0 - clamp(abs(timeAngle - 0.5) * 8.0 - 1.5, 0.0, 1.0);
	float dfade = 1.0 - pow(1.0 - timeBrightness, 1.5);

	L.lightSun = mix(mix(lightMorning, lightEvening, mefade), lightDay, dfade);
	vec3 ambientSun = mix(mix(ambientMorning, ambientEvening, mefade), ambientDay, dfade);

	vec3 lightColRaw = mix(L.lightNight, L.lightSun, L.sunVisibility);
	vec3 lightColSqrt = mix(lightColRaw, VxLuminance(lightColRaw) * L.weatherCol.rgb, rainStrength);
	L.lightCol = lightColSqrt * lightColSqrt;

	vec3 ambientColRaw = mix(ambientNight, ambientSun, L.sunVisibility);
	vec3 ambientColSqrt = mix(ambientColRaw, VxLuminance(ambientColRaw) * L.weatherCol.rgb, rainStrength);
	L.ambientCol = ambientColSqrt * ambientColSqrt;
	#endif

	return L;
}

//Port of GetLighting (forwardLighting.glsl) for LoDs: shadow map is never in range out here
vec3 VxGetLighting(VxLight L, vec3 albedo, vec3 normal, vec2 lightmap, float NoL, float vanillaDiffuse,
                   float emission, float basicSubsurface) {
	#if EMISSIVE == 0
	emission = 0.0;
	#endif
	#ifndef BASIC_SSS
	basicSubsurface = 0.0;
	#endif

	float skylightSqr = lightmap.y * lightmap.y;
	vec3 sceneLighting = vec3(0.0);

	#if defined OVERWORLD || defined END
	if (basicSubsurface > 0.0) NoL = mix(NoL, 1.0, sqrt(basicSubsurface) * 0.7);

	#ifdef SHADOW
	//LoDs are never in the shadow map, so fake occlusion from skylight:
	//faces under trees, overhangs and cliffs lose direct sun like they would in the map
	float skylightShadow = smoothstep(SHADOW_SKY_FALLOFF, 1.0, lightmap.y);
	vec3 fullShadow = vec3(clamp(NoL * 1.01 - 0.01, 0.0, 1.0) * skylightShadow * skylightShadow);
	#else
	float skylightShadow = smoothstep(SHADOW_SKY_FALLOFF, 1.0, lightmap.y);
	vec3 fullShadow = vec3(skylightShadow * skylightShadow);
	#ifdef OVERWORLD
	float timeBrightnessAbs = abs(sin(timeAngle * 6.28318530718));
	fullShadow *= 0.25 + 0.5 * (1.0 - (1.0 - timeBrightnessAbs) * (1.0 - timeBrightnessAbs));
	fullShadow *= mix(pow(vanillaDiffuse, 1.0 + timeBrightnessAbs), 1.0, basicSubsurface * 0.4);
	#else
	fullShadow *= 0.75;
	#endif
	#endif

	#ifdef OVERWORLD
	float shadowMult = (1.0 - 0.95 * rainStrength) * shadowFade;
	sceneLighting = mix(L.ambientCol * lightmap.y, L.lightCol, fullShadow * shadowMult);
	sceneLighting *= skylightSqr;
	#ifdef CLASSIC_EXPOSURE
	sceneLighting *= 4.0 - 3.0 * eBS;
	#endif
	#endif

	#ifdef END
	vec4 endColSqrt = vec4(vec3(END_R, END_G, END_B) / 255.0, 1.0) * END_I;
	vec4 endCol = endColSqrt * endColSqrt;
	sceneLighting = endCol.rgb * (0.04 * fullShadow + 0.015);
	#endif

	#else
	vec4 netherColSqrt = vec4(vec3(NETHER_NR, NETHER_NG, NETHER_NB) / 255.0, 1.0) * NETHER_NI;
	sceneLighting = netherColSqrt.rgb * 0.005;
	#endif

	float newLightmap  = pow(lightmap.x, 10.0) * 1.6 + lightmap.x * 0.6;
	vec3 blockLighting = L.blocklightCol * newLightmap * newLightmap;
	vec3 minLighting = L.minLightCol * (1.0 - skylightSqr);

	vec3 albedoNormalized = normalize(albedo + 0.00001);
	emission = pow(emission, max(EMISSIVE_CURVE, 1.0));
	vec3 emissiveLighting = mix(albedoNormalized, vec3(1.0), emission * 0.5) * emission * EMISSIVE_INTENSITY;

	float lightFlatten = clamp(1.0 - pow(1.0 - emission, 128.0), 0.0, 1.0);
	vanillaDiffuse = mix(vanillaDiffuse, 1.0, lightFlatten);

	#ifdef ALBEDO_BALANCING
	float albedoBrightness = max(max(albedo.r, albedo.g), albedo.b);
	albedo /= 1.0 + albedoBrightness * 0.25 * (1.0 - lightFlatten);
	#endif

	albedo *= max(sceneLighting + blockLighting + emissiveLighting + nightVision * 0.25 + minLighting, vec3(0.0));
	albedo *= vanillaDiffuse;
	return albedo;
}

#ifdef OVERWORLD
//World-space port of GetSkyColor (sky.glsl), used for distant water reflections
vec3 VxGetSkyColor(VxLight L, vec3 dir) {
	#if SKY_VANILLA_INTERNAL == 1
	vec3 skyCol = pow(vx_skyColor, vec3(2.2)) * SKY_I * SKY_I;
	vec3 fogCol = skyCol; //fogColor is not exposed to Iris custom uniforms
	#else
	vec3 skyColSqrt = vec3(SKY_R, SKY_G, SKY_B) * SKY_I / 255.0;
	vec3 fogColSqrt = vec3(FOG_R, FOG_G, FOG_B) * FOG_I / 255.0;
	vec3 skyCol = skyColSqrt * skyColSqrt;
	vec3 fogCol = fogColSqrt * fogColSqrt;
	#endif

	float VoU = clamp(dir.y, -1.0, 1.0);
	float VoL = clamp(dot(dir, L.sunVec), -1.0, 1.0);

	float exposure = exp2(timeBrightness * 0.75 - 0.75 + SKY_EXPOSURE_D);
	float nightExposure = exp2(-3.5 + SKY_EXPOSURE_N);
	float weatherExposure = exp2(SKY_EXPOSURE_W);

	float gradientCurve = mix(SKY_HORIZON_F, SKY_HORIZON_N, VoL);
	float baseGradient = exp(-(1.0 - pow(1.0 - max(VoU, 0.0), gradientCurve)) / SKY_DENSITY_D);

	vec3 sky = skyCol;
	#ifdef USE_FOG_COLOR
	sky = mix(sky, fogCol, pow(1.0 - max(VoU, 0.0), 4.0) * SKY_BLEND);
	#endif
	sky *= baseGradient / (SKY_I * SKY_I);
	sky = sky / sqrt(sky * sky + 1.0) * exposure * L.sunSkyVisibility * (SKY_I * SKY_I);

	float sunMix = pow((VoL * 0.5 + 0.5) * clamp(1.0 - VoU, 0.0, 1.0), 2.0 - L.sunSkyVisibility) *
	               pow(1.0 - timeBrightness * 0.6, 3.0);
	float horizonMix = pow(1.0 - abs(VoU), 2.5) * 0.125;
	float lightMix = (1.0 - (1.0 - sunMix) * (1.0 - horizonMix));

	vec3 lightSky = pow(L.lightSun, vec3(4.0 - L.sunSkyVisibility)) * baseGradient;
	lightSky = lightSky / (1.0 + lightSky * rainStrength);

	sky = mix(sqrt(sky * (1.0 - lightMix)), sqrt(lightSky), lightMix);
	sky *= sky;

	float nightGradient = exp(-max(VoU, 0.0) / SKY_DENSITY_N);
	vec3 nightSky = L.lightNight * L.lightNight * nightGradient * nightExposure;

	float maxSunVisibility = max(L.sunVisibility, L.sunSkyVisibility);
	sky = mix(nightSky, sky, maxSunVisibility * maxSunVisibility);

	float rainGradient = exp(-max(VoU, 0.0) / SKY_DENSITY_W);
	vec3 weatherSky = L.weatherCol.rgb * L.weatherCol.rgb * weatherExposure;
	weatherSky *= VxLuminance(L.ambientCol / weatherSky) * (0.2 * L.sunSkyVisibility + 0.2);
	sky = mix(sky, weatherSky * rainGradient, rainStrength);

	#ifdef SKY_UNDERGROUND
	float ug = mix(clamp((vx_cameraY - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	sky = mix(L.minLightCol * 0.125, sky, ug);
	#endif

	return sky;
}
#endif

void voxy_emitFragment(VoxyFragmentParameters parameters) {
	VxLight L = VxSetupLight();

	int blockID = int(parameters.customId) / 100;
	vec4 albedo = parameters.sampledColour * parameters.tinting;
	vec3 normal = VxFaceNormal(parameters.face);

	//Voxy lightmap UV = level/15 + 1/32, the pack wants level/15
	vec2 lightmap = clamp(parameters.lightMap - 0.03125, vec2(0.0), vec2(0.9333, 1.0));

	#ifndef VX_TRANSLUCENT
	albedo.a = 1.0;
	float foliage  = float(blockID >= 100 && blockID < 150);
	float leaves   = float(blockID == 105 || blockID == 106);
	float emissive = float(blockID >= 150 && blockID < 200);
	float lava     = float(blockID == 153);
	if (lava > 0.5) lightmap.x = min(lightmap.x + 0.0667, 1.0);
	if (leaves > 0.5) albedo.rgb *= 1.3;
	albedo.rgb = clamp(albedo.rgb, vec3(0.0), vec3(1.0));
	#else
	float foliage = 0.0, leaves = 0.0, emissive = 0.0, lava = 0.0;
	float water = float(blockID == 200 || blockID == 204);
	float portal = float(blockID == 203);
	emissive = portal;
	#endif

	float emission = 0.0;
	if (emissive + lava > 0.5) {
		emission = VxHardcodedEmission(albedo.rgb, VxRGB2HSV(albedo.rgb));
	}

	#ifdef VX_TRANSLUCENT
	albedo.rgb /= max(albedo.a, 0.001);
	#endif
	albedo.rgb = pow(albedo.rgb, vec3(2.2));

	#ifdef WHITE_WORLD
	albedo.rgb = vec3(0.35);
	#endif

	#ifdef VX_TRANSLUCENT
	if (water > 0.5) {
		vec4 waterColorSqrt = vec4(vec3(WATER_R, WATER_G, WATER_B) / 255.0, 1.0) * WATER_I;
		vec4 waterColor = waterColorSqrt * waterColorSqrt;
		#if WATER_MODE_INTERNAL == 0 || WATER_MODE_INTERNAL == 2
		albedo.rgb = waterColor.rgb * waterColor.a / max(albedo.a, 0.001);
		#elif WATER_MODE_INTERNAL == 1
		albedo.rgb *= WATER_VI * WATER_VI;
		#else
		albedo.rgb *= WATER_VI * WATER_VI * 2.0;
		#endif
		#if WATER_ALPHA_MODE_INTERNAL == 0
		albedo.a = WATER_A;
		#else
		albedo.a = pow(albedo.a, WATER_VA);
		#endif
	}
	#endif

	#if HALF_LAMBERT_INTERNAL == 0
	float NoL = clamp(dot(normal, L.lightVec), 0.0, 1.0);
	#else
	float NoL = clamp(dot(normal, L.lightVec) * 0.5 + 0.5, 0.0, 1.0);
	NoL *= NoL;
	#endif

	float NoU = normal.y;
	float NoE = normal.x;
	float vanillaDiffuse = (0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
	vanillaDiffuse *= vanillaDiffuse;

	#ifndef NORMAL_PLANTS
	if (foliage > 0.5) vanillaDiffuse *= 1.8;
	#endif

	float basicSubsurface = leaves * 0.5;
	if (leaves > 0.5) {
		float halfNoL = dot(normal, L.lightVec) * 0.5 + 0.5;
		basicSubsurface *= halfNoL * step(length(albedo.rgb), 1.7);
	}

	albedo.rgb = VxGetLighting(L, albedo.rgb, normal, lightmap, NoL, vanillaDiffuse, emission, basicSubsurface);

	#if defined VX_TRANSLUCENT && REFLECTION > 0
	if (water > 0.5) {
		//Reconstruct the view ray from Voxy's own scene matrix (only water pays for this)
		vec2 screenSize = vec2(textureSize(depthTex, 0));
		vec4 ndc = vec4(gl_FragCoord.xy / screenSize * 2.0 - 1.0, gl_FragCoord.z * 2.0 - 1.0, 1.0);
		vec4 localPos = inverse(MVP) * ndc;
		vec3 viewDir = normalize(localPos.xyz / localPos.w - cameraSubPos);

		float fresnel = pow(clamp(1.0 + dot(normal, viewDir), 0.0, 1.0), 5.0);
		fresnel = fresnel * 0.98 + 0.02;

		vec3 skyReflection = vec3(0.0);
		#ifdef OVERWORLD
		skyReflection = VxGetSkyColor(L, reflect(viewDir, normal));
		#ifdef CLASSIC_EXPOSURE
		skyReflection *= 4.0 - 3.0 * eBS;
		#endif
		float waterSkyOcclusion = lightmap.y;
		#if REFLECTION_SKY_FALLOFF > 1
		waterSkyOcclusion = clamp(1.0 - (1.0 - waterSkyOcclusion) * REFLECTION_SKY_FALLOFF, 0.0, 1.0);
		#endif
		skyReflection *= waterSkyOcclusion * waterSkyOcclusion;
		#endif
		#ifdef NETHER
		vec4 netherColSqrtR = vec4(vec3(NETHER_NR, NETHER_NG, NETHER_NB) / 255.0, 1.0) * NETHER_NI;
		skyReflection = netherColSqrtR.rgb * netherColSqrtR.rgb * 0.04;
		#endif
		#ifdef END
		vec4 endColSqrtR = vec4(vec3(END_R, END_G, END_B) / 255.0, 1.0) * END_I;
		skyReflection = endColSqrtR.rgb * endColSqrtR.rgb * 0.01;
		#endif

		albedo.rgb = mix(albedo.rgb, max(skyReflection, vec3(0.0)), fresnel);
		albedo.a = mix(albedo.a, 1.0, fresnel);
	}
	#endif

	#if ALPHA_BLEND == 0
	albedo.rgb = sqrt(max(albedo.rgb, vec3(0.0)));
	#endif

	vxFragOut0 = albedo;
}
