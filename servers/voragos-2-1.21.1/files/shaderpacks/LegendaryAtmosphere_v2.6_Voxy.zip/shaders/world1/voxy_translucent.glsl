/* Voxy LoD translucent patch - Legendary Atmosphere */
#define END
#define VX_TRANSLUCENT

#include "/lib/voxy/voxyPatch.glsl"
