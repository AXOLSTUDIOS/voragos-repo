/* Voxy LoD opaque patch - Legendary Atmosphere */
#define END

#include "/lib/voxy/voxyPatch.glsl"
