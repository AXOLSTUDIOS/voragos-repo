/* Voxy LoD opaque patch - Legendary Atmosphere */
#define OVERWORLD

#include "/lib/voxy/voxyPatch.glsl"
