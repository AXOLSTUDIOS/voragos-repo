/* Voxy LoD translucent patch - Legendary Atmosphere */
#define OVERWORLD
#define VX_TRANSLUCENT

#include "/lib/voxy/voxyPatch.glsl"
