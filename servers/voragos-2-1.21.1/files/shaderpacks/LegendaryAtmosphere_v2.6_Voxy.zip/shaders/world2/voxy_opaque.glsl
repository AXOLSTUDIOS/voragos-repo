/* Voxy LoD opaque patch - Legendary Atmosphere */
#define OVERWORLD
#define AIRSHIP

#include "/lib/voxy/voxyPatch.glsl"
