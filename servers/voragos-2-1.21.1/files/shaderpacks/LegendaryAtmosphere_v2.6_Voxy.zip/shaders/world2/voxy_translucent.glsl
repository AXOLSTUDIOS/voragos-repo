/* Voxy LoD translucent patch - Legendary Atmosphere */
#define OVERWORLD
#define AIRSHIP
#define VX_TRANSLUCENT

#include "/lib/voxy/voxyPatch.glsl"
