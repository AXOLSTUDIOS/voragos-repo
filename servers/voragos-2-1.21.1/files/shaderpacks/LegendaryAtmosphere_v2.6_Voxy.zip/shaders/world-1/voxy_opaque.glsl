/* Voxy LoD opaque patch - Legendary Atmosphere */
#define NETHER

#include "/lib/voxy/voxyPatch.glsl"
