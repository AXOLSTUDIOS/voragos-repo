/* Voxy LoD translucent patch - Legendary Atmosphere */
#define NETHER
#define VX_TRANSLUCENT

#include "/lib/voxy/voxyPatch.glsl"
