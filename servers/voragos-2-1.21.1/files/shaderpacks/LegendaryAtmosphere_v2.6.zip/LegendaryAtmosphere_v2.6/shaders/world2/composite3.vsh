/* 
BSL Shaders v10 Series by Capt Tatsu 
https://capttatsu.com 
*/ 

#version 120 

#define OVERWORLD
#define AIRSHIP
#define VSH

#include "/program/composite3.glsl"
